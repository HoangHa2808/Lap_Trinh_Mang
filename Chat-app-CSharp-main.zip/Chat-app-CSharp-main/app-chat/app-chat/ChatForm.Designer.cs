﻿namespace app_chat
{
    partial class ChatForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gunaPanel1 = new Guna.UI.WinForms.GunaPanel();
            this.gunaImageButton4 = new Guna.UI.WinForms.GunaImageButton();
            this.gunaImageButton3 = new Guna.UI.WinForms.GunaImageButton();
            this.gunaImageButton2 = new Guna.UI.WinForms.GunaImageButton();
            this.gunaImageButton1 = new Guna.UI.WinForms.GunaImageButton();
            this.gunaCirclePictureBox1 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.gunaPanel4 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPictureBox1 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaTextBox1 = new Guna.UI.WinForms.GunaTextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.gunaPanel5 = new Guna.UI.WinForms.GunaPanel();
            this.gunaImageButton7 = new Guna.UI.WinForms.GunaImageButton();
            this.gunaImageButton6 = new Guna.UI.WinForms.GunaImageButton();
            this.gunaImageButton5 = new Guna.UI.WinForms.GunaImageButton();
            this.gunaPanel3 = new Guna.UI.WinForms.GunaPanel();
            this.lbNameChat = new Guna.UI.WinForms.GunaLabel();
            this.ListChat = new System.Windows.Forms.ListView();
            this.gunaPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).BeginInit();
            this.gunaPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).BeginInit();
            this.gunaPanel5.SuspendLayout();
            this.gunaPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // gunaPanel1
            // 
            this.gunaPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(149)))), ((int)(((byte)(255)))));
            this.gunaPanel1.Controls.Add(this.gunaImageButton4);
            this.gunaPanel1.Controls.Add(this.gunaImageButton3);
            this.gunaPanel1.Controls.Add(this.gunaImageButton2);
            this.gunaPanel1.Controls.Add(this.gunaImageButton1);
            this.gunaPanel1.Controls.Add(this.gunaCirclePictureBox1);
            this.gunaPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.gunaPanel1.Location = new System.Drawing.Point(0, 0);
            this.gunaPanel1.Name = "gunaPanel1";
            this.gunaPanel1.Size = new System.Drawing.Size(71, 728);
            this.gunaPanel1.TabIndex = 0;
            // 
            // gunaImageButton4
            // 
            this.gunaImageButton4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaImageButton4.Image = global::app_chat.Properties.Resources.star;
            this.gunaImageButton4.ImageSize = new System.Drawing.Size(50, 50);
            this.gunaImageButton4.Location = new System.Drawing.Point(9, 302);
            this.gunaImageButton4.Name = "gunaImageButton4";
            this.gunaImageButton4.OnHoverImage = null;
            this.gunaImageButton4.OnHoverImageOffset = new System.Drawing.Point(0, 0);
            this.gunaImageButton4.Size = new System.Drawing.Size(52, 58);
            this.gunaImageButton4.TabIndex = 4;
            // 
            // gunaImageButton3
            // 
            this.gunaImageButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaImageButton3.Image = global::app_chat.Properties.Resources.setting_2;
            this.gunaImageButton3.ImageSize = new System.Drawing.Size(50, 50);
            this.gunaImageButton3.Location = new System.Drawing.Point(8, 643);
            this.gunaImageButton3.Name = "gunaImageButton3";
            this.gunaImageButton3.OnHoverImage = null;
            this.gunaImageButton3.OnHoverImageOffset = new System.Drawing.Point(0, 0);
            this.gunaImageButton3.Size = new System.Drawing.Size(52, 58);
            this.gunaImageButton3.TabIndex = 3;
            this.gunaImageButton3.Click += new System.EventHandler(this.gunaImageButton3_Click);
            // 
            // gunaImageButton2
            // 
            this.gunaImageButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaImageButton2.Image = global::app_chat.Properties.Resources.people1;
            this.gunaImageButton2.ImageSize = new System.Drawing.Size(50, 50);
            this.gunaImageButton2.Location = new System.Drawing.Point(8, 220);
            this.gunaImageButton2.Name = "gunaImageButton2";
            this.gunaImageButton2.OnHoverImage = null;
            this.gunaImageButton2.OnHoverImageOffset = new System.Drawing.Point(0, 0);
            this.gunaImageButton2.Size = new System.Drawing.Size(52, 58);
            this.gunaImageButton2.TabIndex = 2;
            // 
            // gunaImageButton1
            // 
            this.gunaImageButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaImageButton1.Image = global::app_chat.Properties.Resources.message;
            this.gunaImageButton1.ImageSize = new System.Drawing.Size(50, 50);
            this.gunaImageButton1.Location = new System.Drawing.Point(9, 135);
            this.gunaImageButton1.Name = "gunaImageButton1";
            this.gunaImageButton1.OnHoverImage = null;
            this.gunaImageButton1.OnHoverImageOffset = new System.Drawing.Point(0, 0);
            this.gunaImageButton1.Size = new System.Drawing.Size(52, 58);
            this.gunaImageButton1.TabIndex = 1;
            this.gunaImageButton1.Click += new System.EventHandler(this.gunaImageButton1_Click);
            // 
            // gunaCirclePictureBox1
            // 
            this.gunaCirclePictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(149)))), ((int)(((byte)(255)))));
            this.gunaCirclePictureBox1.BaseColor = System.Drawing.Color.RosyBrown;
            this.gunaCirclePictureBox1.Image = global::app_chat.Properties.Resources.R;
            this.gunaCirclePictureBox1.Location = new System.Drawing.Point(8, 6);
            this.gunaCirclePictureBox1.Name = "gunaCirclePictureBox1";
            this.gunaCirclePictureBox1.Size = new System.Drawing.Size(53, 56);
            this.gunaCirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaCirclePictureBox1.TabIndex = 0;
            this.gunaCirclePictureBox1.TabStop = false;
            this.gunaCirclePictureBox1.UseTransfarantBackground = false;
            // 
            // gunaPanel4
            // 
            this.gunaPanel4.BackColor = System.Drawing.Color.White;
            this.gunaPanel4.Controls.Add(this.gunaPictureBox1);
            this.gunaPanel4.Controls.Add(this.gunaTextBox1);
            this.gunaPanel4.Controls.Add(this.listView1);
            this.gunaPanel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.gunaPanel4.Location = new System.Drawing.Point(71, 0);
            this.gunaPanel4.Name = "gunaPanel4";
            this.gunaPanel4.Size = new System.Drawing.Size(302, 728);
            this.gunaPanel4.TabIndex = 3;
            // 
            // gunaPictureBox1
            // 
            this.gunaPictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox1.Image = global::app_chat.Properties.Resources.search_normal;
            this.gunaPictureBox1.Location = new System.Drawing.Point(11, 17);
            this.gunaPictureBox1.Name = "gunaPictureBox1";
            this.gunaPictureBox1.Size = new System.Drawing.Size(34, 32);
            this.gunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox1.TabIndex = 2;
            this.gunaPictureBox1.TabStop = false;
            // 
            // gunaTextBox1
            // 
            this.gunaTextBox1.BackColor = System.Drawing.Color.Transparent;
            this.gunaTextBox1.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(149)))), ((int)(((byte)(255)))));
            this.gunaTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox1.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox1.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox1.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox1.Location = new System.Drawing.Point(58, 15);
            this.gunaTextBox1.Name = "gunaTextBox1";
            this.gunaTextBox1.PasswordChar = '\0';
            this.gunaTextBox1.Radius = 10;
            this.gunaTextBox1.SelectedText = "";
            this.gunaTextBox1.Size = new System.Drawing.Size(221, 36);
            this.gunaTextBox1.TabIndex = 1;
            // 
            // listView1
            // 
            this.listView1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(0, 66);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(302, 662);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // gunaPanel5
            // 
            this.gunaPanel5.BackColor = System.Drawing.Color.White;
            this.gunaPanel5.Controls.Add(this.gunaImageButton7);
            this.gunaPanel5.Controls.Add(this.gunaImageButton6);
            this.gunaPanel5.Controls.Add(this.gunaImageButton5);
            this.gunaPanel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.gunaPanel5.Location = new System.Drawing.Point(373, 661);
            this.gunaPanel5.Name = "gunaPanel5";
            this.gunaPanel5.Size = new System.Drawing.Size(867, 67);
            this.gunaPanel5.TabIndex = 4;
            // 
            // gunaImageButton7
            // 
            this.gunaImageButton7.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaImageButton7.Image = global::app_chat.Properties.Resources.send_2;
            this.gunaImageButton7.ImageSize = new System.Drawing.Size(40, 40);
            this.gunaImageButton7.Location = new System.Drawing.Point(806, 8);
            this.gunaImageButton7.Name = "gunaImageButton7";
            this.gunaImageButton7.OnHoverImage = null;
            this.gunaImageButton7.OnHoverImageOffset = new System.Drawing.Point(0, 0);
            this.gunaImageButton7.Size = new System.Drawing.Size(49, 47);
            this.gunaImageButton7.TabIndex = 4;
            // 
            // gunaImageButton6
            // 
            this.gunaImageButton6.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaImageButton6.Image = global::app_chat.Properties.Resources.gallery;
            this.gunaImageButton6.ImageSize = new System.Drawing.Size(40, 40);
            this.gunaImageButton6.Location = new System.Drawing.Point(64, 8);
            this.gunaImageButton6.Name = "gunaImageButton6";
            this.gunaImageButton6.OnHoverImage = null;
            this.gunaImageButton6.OnHoverImageOffset = new System.Drawing.Point(0, 0);
            this.gunaImageButton6.Size = new System.Drawing.Size(49, 47);
            this.gunaImageButton6.TabIndex = 3;
            // 
            // gunaImageButton5
            // 
            this.gunaImageButton5.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaImageButton5.Image = global::app_chat.Properties.Resources.carbon_face_satisfied;
            this.gunaImageButton5.ImageSize = new System.Drawing.Size(40, 40);
            this.gunaImageButton5.Location = new System.Drawing.Point(6, 8);
            this.gunaImageButton5.Name = "gunaImageButton5";
            this.gunaImageButton5.OnHoverImage = null;
            this.gunaImageButton5.OnHoverImageOffset = new System.Drawing.Point(0, 0);
            this.gunaImageButton5.Size = new System.Drawing.Size(49, 47);
            this.gunaImageButton5.TabIndex = 2;
            // 
            // gunaPanel3
            // 
            this.gunaPanel3.BackColor = System.Drawing.Color.White;
            this.gunaPanel3.Controls.Add(this.lbNameChat);
            this.gunaPanel3.Location = new System.Drawing.Point(373, 0);
            this.gunaPanel3.Name = "gunaPanel3";
            this.gunaPanel3.Size = new System.Drawing.Size(867, 68);
            this.gunaPanel3.TabIndex = 2;
            // 
            // lbNameChat
            // 
            this.lbNameChat.AutoSize = true;
            this.lbNameChat.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNameChat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(149)))), ((int)(((byte)(255)))));
            this.lbNameChat.Location = new System.Drawing.Point(27, 21);
            this.lbNameChat.Name = "lbNameChat";
            this.lbNameChat.Size = new System.Drawing.Size(187, 28);
            this.lbNameChat.TabIndex = 0;
            this.lbNameChat.Text = "Tên người chat";
            // 
            // ListChat
            // 
            this.ListChat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.ListChat.HideSelection = false;
            this.ListChat.Location = new System.Drawing.Point(373, 66);
            this.ListChat.Name = "ListChat";
            this.ListChat.Size = new System.Drawing.Size(867, 597);
            this.ListChat.TabIndex = 5;
            this.ListChat.UseCompatibleStateImageBehavior = false;
            // 
            // ChatForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(1240, 728);
            this.Controls.Add(this.ListChat);
            this.Controls.Add(this.gunaPanel5);
            this.Controls.Add(this.gunaPanel4);
            this.Controls.Add(this.gunaPanel3);
            this.Controls.Add(this.gunaPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ChatForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChatForm";
            this.gunaPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).EndInit();
            this.gunaPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).EndInit();
            this.gunaPanel5.ResumeLayout(false);
            this.gunaPanel3.ResumeLayout(false);
            this.gunaPanel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI.WinForms.GunaPanel gunaPanel1;
        private Guna.UI.WinForms.GunaPanel gunaPanel4;
        private Guna.UI.WinForms.GunaPanel gunaPanel5;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox1;
        private Guna.UI.WinForms.GunaImageButton gunaImageButton1;
        private Guna.UI.WinForms.GunaPanel gunaPanel3;
        private Guna.UI.WinForms.GunaImageButton gunaImageButton2;
        private Guna.UI.WinForms.GunaImageButton gunaImageButton4;
        private Guna.UI.WinForms.GunaImageButton gunaImageButton3;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox1;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox1;
        private System.Windows.Forms.ListView listView1;
        private Guna.UI.WinForms.GunaImageButton gunaImageButton5;
        private Guna.UI.WinForms.GunaLabel lbNameChat;
        private Guna.UI.WinForms.GunaImageButton gunaImageButton6;
        private Guna.UI.WinForms.GunaImageButton gunaImageButton7;
        private System.Windows.Forms.ListView ListChat;
    }
}