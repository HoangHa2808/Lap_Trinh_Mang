﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace app_chat.Controler
{
     class Client
    {
        /// <summary>
        /// Kết nối đến server
        /// </summary>
        public void Connect()
        {

        }
        
        /// <summary>
        /// Đóng kết nối
        /// </summary>
        public void Close()
        {

        }

        /// <summary>
        /// Gửi tin
        /// </summary>
        public void Send()
        {

        }

        /// <summary>
        /// Nhận tin
        /// </summary>
        public void Receive()
        {

        }

        /// <summary>
        /// Chuyển dữ liệu thành byte
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        byte[] Serialize(object obj)
        {

        }

        /// <summary>
        /// Byte thành dữ liệu
        /// </summary>
        /// <returns></returns>
        object Deserialize(byte[] data)
        {

        }
    }
}
